using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShotMovement : MonoBehaviour
{
    public float Speedshot = 20;
    void Start()
    {

    }
    void Update()
    {
        transform.Translate(Vector3.up  * Speedshot * Time.deltaTime);
        Destroy(this.gameObject,1f);
    }
}
