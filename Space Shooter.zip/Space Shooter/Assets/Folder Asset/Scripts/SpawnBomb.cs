using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnBomb : MonoBehaviour
{
    public GameObject Bombs;
    public float SpawnRate;

    void Start()
    {
        StartCoroutine(SpawnCoroutine());
    }
    IEnumerator SpawnCoroutine()
    {
        while (true)
        {
            Spawn();
            yield return new WaitForSeconds(SpawnRate);
        }
    }
    void Spawn()
    {
        float X_Random = Random.Range(-3, 3);
        Vector2 Spawn_Posit = new Vector2(X_Random, transform.position.y);
        GameObject newBomb = Instantiate(Bombs, Spawn_Posit, Quaternion.identity);
        Destroy(newBomb, 4f);
    }
}
