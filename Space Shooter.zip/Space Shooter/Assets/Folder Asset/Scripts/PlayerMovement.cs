using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public GameObject Bullet;
    public float speedPlayer = 5;
    public float DelayShot = 0.015f;
    public Animator AnimatorPlayer;
    void Start()
    {
        StartCoroutine(ShootWithDelay());
    }
    void Update()
    {
        if ((Input.GetAxis("Horizontal") != 0 || Input.GetAxis("Vertical") != 0) && AnimatorPlayer.applyRootMotion == false)
        {
            AnimatorPlayer.applyRootMotion = true;
        }
        transform.Translate(new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical")) * speedPlayer * Time.deltaTime);
        transform.position = new Vector3(Mathf.Clamp(transform.position.x, -2.9f, 2.9f), Mathf.Clamp(transform.position.y, -4, 5.8f), -0.17f);
    }
    IEnumerator ShootWithDelay()
    {
        while (true)
        {
            yield return new WaitForSeconds(DelayShot);
            ShootBullet();
        }
    }
    void ShootBullet()
    {
        Instantiate(Bullet, transform.position, Quaternion.identity);
    }
}